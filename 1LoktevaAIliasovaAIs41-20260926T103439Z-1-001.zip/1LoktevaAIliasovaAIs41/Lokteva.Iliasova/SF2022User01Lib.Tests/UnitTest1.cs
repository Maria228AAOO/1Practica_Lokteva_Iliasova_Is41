﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using SF2022User01Lib;

namespace SF2022User01Lib.Tests
{
    [TestClass]
    public class CalculationsTests
    {
        // Тест 1: Стандартный рабочий день с несколькими занятыми интервалами
        [TestMethod]
        public void AvailablePeriods_StandardDay_ReturnsCorrectSlots()
        {
            TimeSpan[] startTimes = { new TimeSpan(10, 0, 0), new TimeSpan(12, 0, 0) };
            int[] durations = { 60, 30 };
            TimeSpan begin = new TimeSpan(9, 0, 0);
            TimeSpan end = new TimeSpan(14, 0, 0);
            int consult = 30;

            string[] result = Calculations.AvailablePeriods(startTimes, durations, begin, end, consult);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Length > 0);
        }

        // Тест 2: Полностью свободный день менеджера
        [TestMethod]
        public void AvailablePeriods_AllDayFree_ReturnsFullSlots()
        {
            TimeSpan[] startTimes = new TimeSpan[0];
            int[] durations = new int[0];
            TimeSpan begin = new TimeSpan(8, 0, 0);
            TimeSpan end = new TimeSpan(10, 0, 0);
            int consult = 30;

            string[] result = Calculations.AvailablePeriods(startTimes, durations, begin, end, consult);

            Assert.AreEqual(4, result.Length); // 4 слота по 30 минут за 2 часа
        }

        // Тест 3: Весь день полностью занят, свободных окон быть не должно
        [TestMethod]
        public void AvailablePeriods_AllDayBusy_ReturnsEmpty()
        {
            TimeSpan[] startTimes = { new TimeSpan(8, 0, 0) };
            int[] durations = { 120 };
            TimeSpan begin = new TimeSpan(8, 0, 0);
            TimeSpan end = new TimeSpan(10, 0, 0);
            int consult = 30;

            string[] result = Calculations.AvailablePeriods(startTimes, durations, begin, end, consult);

            Assert.AreEqual(0, result.Length);
        }

        // Тест 4: Время консультации больше, чем весь рабочий день
        [TestMethod]
        public void AvailablePeriods_ConsultationLongerThanWorkDay_ReturnsEmpty()
        {
            TimeSpan[] startTimes = new TimeSpan[0];
            int[] durations = new int[0];
            TimeSpan begin = new TimeSpan(9, 0, 0);
            TimeSpan end = new TimeSpan(10, 0, 0);
            int consult = 120; // 2 часа при рабочем дне в 1 час

            string[] result = Calculations.AvailablePeriods(startTimes, durations, begin, end, consult);

            Assert.AreEqual(0, result.Length);
        }

        // Тест 5: Консультация впритык заполняет единственный свободный интервал
        [TestMethod]
        public void AvailablePeriods_ExactMatchSlot_ReturnsOneSlot()
        {
            TimeSpan[] startTimes = { new TimeSpan(8, 0, 0), new TimeSpan(9, 30, 0) };
            int[] durations = { 60, 30 }; // Окно между ними с 09:00 до 09:30
            TimeSpan begin = new TimeSpan(8, 0, 0);
            TimeSpan end = new TimeSpan(10, 0, 0);
            int consult = 30;

            string[] result = Calculations.AvailablePeriods(startTimes, durations, begin, end, consult);

            Assert.AreEqual(1, result.Length);
            Assert.AreEqual("09:00-09:30", result[0]);
        }

        // Тест 6: Очень короткая консультация (1 минута)
        [TestMethod]
        public void AvailablePeriods_MicroConsultation_ReturnsSlots()
        {
            TimeSpan[] startTimes = new TimeSpan[0];
            int[] durations = new int[0];
            TimeSpan begin = new TimeSpan(9, 0, 0);
            TimeSpan end = new TimeSpan(9, 05, 0);
            int consult = 1;

            string[] result = Calculations.AvailablePeriods(startTimes, durations, begin, end, consult);

            Assert.AreEqual(5, result.Length);
        }

        // Тест 7: Проверка корректности формата строк (hh:mm-hh:mm)
        [TestMethod]
        public void AvailablePeriods_CheckStringFormat_ReturnsValidFormat()
        {
            TimeSpan[] startTimes = new TimeSpan[0];
            int[] durations = new int[0];
            TimeSpan begin = new TimeSpan(10, 0, 0);
            TimeSpan end = new TimeSpan(10, 30, 0);
            int consult = 30;

            string[] result = Calculations.AvailablePeriods(startTimes, durations, begin, end, consult);

            Assert.AreEqual("10:00-10:30", result[0]);
        }

        // Тест 8: Занятые интервалы идут один за другим без перерыва
        [TestMethod]
        public void AvailablePeriods_BackToBackBusy_ReturnsCorrect()
        {
            TimeSpan[] startTimes = { new TimeSpan(8, 0, 0), new TimeSpan(9, 0, 0) };
            int[] durations = { 60, 60 };
            TimeSpan begin = new TimeSpan(8, 0, 0);
            TimeSpan end = new TimeSpan(10, 30, 0);
            int consult = 30;

            string[] result = Calculations.AvailablePeriods(startTimes, durations, begin, end, consult);

            Assert.AreEqual(1, result.Length); // Остался свободным только кусок 10:00-10:30
        }

        // Тест 9: Нестандартное время начала (с минутами)
        [TestMethod]
        public void AvailablePeriods_CustomStartTime_ReturnsCorrect()
        {
            TimeSpan[] startTimes = new TimeSpan[0];
            int[] durations = new int[0];
            TimeSpan begin = new TimeSpan(8, 15, 0);
            TimeSpan end = new TimeSpan(8, 45, 0);
            int consult = 30;

            string[] result = Calculations.AvailablePeriods(startTimes, durations, begin, end, consult);

            Assert.AreEqual("08:15-08:45", result[0]);
        }

        // Тест 10: Время окончания рабочего дня совпадает с началом занятого интервала
        [TestMethod]
        public void AvailablePeriods_BusyTimeAtTheEnd_ReturnsEmpty()
        {
            TimeSpan[] startTimes = { new TimeSpan(17, 0, 0) };
            int[] durations = { 60 };
            TimeSpan begin = new TimeSpan(16, 0, 0);
            TimeSpan end = new TimeSpan(17, 0, 0);
            int consult = 30;

            string[] result = Calculations.AvailablePeriods(startTimes, durations, begin, end, consult);

            Assert.IsTrue(result.Length > 0);
        }
    }
}
