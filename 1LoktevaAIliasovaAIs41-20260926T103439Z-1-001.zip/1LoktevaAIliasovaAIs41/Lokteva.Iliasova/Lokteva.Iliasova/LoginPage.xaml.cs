﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using MySql.Data.MySqlClient;

namespace Lokteva.Iliasova
{
    public partial class LoginPage : Page
    {
        private string generatedCaptcha = "";
        private int failedAttempts = 0;
        private DispatcherTimer blockTimer;
        private int timeLeft = 10;

        public LoginPage()
        {
            InitializeComponent();
            Loaded += (s, e) => {
                var win = Window.GetWindow(this);
                if (win != null) win.Title = "Ювелир. Окно авторизации";
            };

            blockTimer = new DispatcherTimer();
            blockTimer.Interval = TimeSpan.FromSeconds(1);
            blockTimer.Tick += BlockTimer_Tick;
        }

        private void GenerateCaptcha()
        {
            CaptchaCanvas.Children.Clear();
            string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            Random rand = new Random();
            generatedCaptcha = "";

            for (int i = 0; i < 4; i++)
            {
                char c = chars[rand.Next(chars.Length)];
                generatedCaptcha += c;

                TextBlock tb = new TextBlock
                {
                    Text = c.ToString(),
                    FontSize = rand.Next(22, 28),
                    FontWeight = FontWeights.Bold,
                    FontStyle = rand.Next(0, 2) == 1 ? FontStyles.Italic : FontStyles.Normal,
                    Foreground = Brushes.DarkSlateGray
                };

                Canvas.SetLeft(tb, 20 + (i * 40) + rand.Next(-5, 5));
                Canvas.SetTop(tb, rand.Next(10, 25));
                CaptchaCanvas.Children.Add(tb);
            }

            for (int i = 0; i < rand.Next(3, 6); i++)
            {
                Line line = new Line
                {
                    X1 = rand.Next(0, 200),
                    Y1 = rand.Next(0, 60),
                    X2 = rand.Next(0, 200),
                    Y2 = rand.Next(0, 60),
                    Stroke = Brushes.DimGray,
                    StrokeThickness = rand.Next(1, 3)
                };
                CaptchaCanvas.Children.Add(line);
            }

            TxtCaptchaInput.Text = "";
        }

        private void StartBlock()
        {
            LoginStackPanel.IsEnabled = false;
            TxtBlockTimer.Visibility = Visibility.Visible;
            timeLeft = 10;
            TxtBlockTimer.Text = $"Система заблокирована на {timeLeft} сек...";
            blockTimer.Start();
        }

        private void BlockTimer_Tick(object sender, EventArgs e)
        {
            timeLeft--;
            if (timeLeft <= 0)
            {
                blockTimer.Stop();
                LoginStackPanel.IsEnabled = true;
                TxtBlockTimer.Visibility = Visibility.Collapsed;
                GenerateCaptcha();
            }
            else
            {
                TxtBlockTimer.Text = $"Система заблокирована на {timeLeft} сек...";
            }
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (CaptchaPanel.Visibility == Visibility.Visible)
            {
                if (TxtCaptchaInput.Text != generatedCaptcha)
                {
                    MessageBox.Show("Капча введена неверно! Вход заблокирован на 10 секунд.");
                    StartBlock();
                    return;
                }
            }

            using (var connection = DatabaseContext.GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = @"
                        SELECT roles.role_name, users.full_name 
                        FROM users 
                        JOIN roles ON users.roles_id = roles.id 
                        WHERE users.login = @login AND users.password = @password";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@login", TxtLogin.Text);
                        command.Parameters.AddWithValue("@password", TxtPassword.Password);

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                failedAttempts = 0;
                                CaptchaPanel.Visibility = Visibility.Collapsed;

                                AuthService.CurrentRole = reader["role_name"].ToString();
                                AuthService.CurrentUserFullName = reader["full_name"].ToString();

                                NavigationService.Navigate(new ProductPage());
                            }
                            else
                            {
                                failedAttempts++;
                                MessageBox.Show("Неверный логин или пароль!");

                                if (failedAttempts >= 1)
                                {
                                    CaptchaPanel.Visibility = Visibility.Visible;
                                    GenerateCaptcha();
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}");
                }
            }
        }

        private void BtnGuest_Click(object sender, RoutedEventArgs e)
        {
            AuthService.CurrentRole = "Гость";
            AuthService.CurrentUserFullName = "Гость";
            NavigationService.Navigate(new ProductPage());
        }
    }
}
