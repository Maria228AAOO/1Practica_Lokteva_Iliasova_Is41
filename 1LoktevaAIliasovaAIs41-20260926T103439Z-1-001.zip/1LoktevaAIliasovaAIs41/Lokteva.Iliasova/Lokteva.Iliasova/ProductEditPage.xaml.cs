﻿using Lokteva.Iliasova;
using Microsoft.Win32;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;  
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media; 
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace Lokteva.Iliasova
{
    public partial class ProductEditPage : Page
    {
        private Product currentProduct = null;
        private bool isEditMode = false;
        private string selectedImagePath = null;
        private string oldImageFileName = null;

        public ProductEditPage(Product product)
        {
            InitializeComponent();
            currentProduct = product;

            if (currentProduct != null)
            {
                isEditMode = true;
                TxtHeader.Text = "Редактирование товара";
                PanelSku.Visibility = Visibility.Visible;
                TxtSku.IsEnabled = false;

                // Заполняем все поля из БД
                TxtSku.Text = currentProduct.Sku;
                TxtName.Text = currentProduct.ProductName;
                TxtPrice.Text = currentProduct.Price.ToString("F2");
                TxtStock.Text = currentProduct.Stock.ToString();
                TxtMaxDiscount.Text = currentProduct.MaxDiscount.ToString();       // Добавили
                TxtCurrentDiscount.Text = currentProduct.CurrentDiscount.ToString(); // Добавили
                TxtUnit.Text = currentProduct.Unit;
                TxtSupplier.Text = currentProduct.Supplier;
                TxtManufacturer.Text = currentProduct.Manufacturer;
                TxtDescription.Text = currentProduct.Description;
                oldImageFileName = currentProduct.ImageFile;

                foreach (ComboBoxItem item in ComboCategory.Items)
                {
                    if (item.Content.ToString() == currentProduct.ProductType)
                    {
                        ComboCategory.SelectedItem = item;
                        break;
                    }
                }

                if (!string.IsNullOrEmpty(currentProduct.FullImagePath) && System.IO.File.Exists(currentProduct.FullImagePath))
                {
                    ImgProduct.Source = new BitmapImage(new Uri(currentProduct.FullImagePath));
                }
                else
                {
                    string stubPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Tovari_import", "picture.png");
                    if (System.IO.File.Exists(stubPath))
                    {
                        ImgProduct.Source = new BitmapImage(new Uri(stubPath));
                    }
                }
            }
            else
            {
                isEditMode = false;
                TxtHeader.Text = "Добавление товара";
                PanelSku.Visibility = Visibility.Collapsed;
            }

            Loaded += (s, e) => {
                var win = Window.GetWindow(this);
                if (win != null) win.Title = isEditMode ? "Ювелир. Окно редактирования" : "Ювелир. Окно добавления";
            };
        }

        private void BtnSelectImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Изображения (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png";

            if (ofd.ShowDialog() == true)
            {
                try
                {
                    BitmapDecoder decoder = BitmapDecoder.Create(new Uri(ofd.FileName), BitmapCreateOptions.None, BitmapCacheOption.OnLoad);

                    // ИСПРАВЛЕНИЕ: берем первый кадр из коллекции через [0]
                    BitmapFrame frame = decoder.Frames[0];

                    if (frame.PixelWidth > 300 || frame.PixelHeight > 200)
                    {
                        MessageBox.Show($"Размер фото ({frame.PixelWidth}x{frame.PixelHeight}) превышает допустимый лимит 300x200 пикселей!", "Ошибка объема фото", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    selectedImagePath = ofd.FileName;
                    ImgProduct.Source = frame;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Не удалось прочитать изображение: {ex.Message}");
                }
            }
        }


        private string GenerateNewSku()
        {
            string newSku = "N" + new Random().Next(100, 999) + "H5";
            using (var connection = DatabaseContext.GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM products";
                    using (var command = new MySqlCommand(query, connection))
                    {
                        int count = Convert.ToInt32(command.ExecuteScalar());
                        newSku = "NEW" + (count + 1);
                    }
                }
                catch { }
            }
            return newSku;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtName.Text) || string.IsNullOrWhiteSpace(TxtPrice.Text) || string.IsNullOrWhiteSpace(TxtStock.Text))
            {
                MessageBox.Show("Пожалуйста, заполните основные поля (Наименование, Цена, Количество)!");
                return;
            }

            if (!decimal.TryParse(TxtPrice.Text.Replace('.', ','), out decimal price) || price < 0)
            {
                MessageBox.Show("Стоимость товара должна быть положительным числом!", "Ошибка валидации цены");
                return;
            }

            if (!int.TryParse(TxtStock.Text, out int stock) || stock < 0)
            {
                MessageBox.Show("Количество на складе не может принимать отрицательные значения!", "Ошибка валидации склада");
                return;
            }

            if (!int.TryParse(TxtMaxDiscount.Text, out int maxDiscount) || maxDiscount < 0 || maxDiscount > 100)
            {
                MessageBox.Show("Максимальная скидка должна быть числом от 0 до 100%!", "Ошибка валидации");
                return;
            }

            if (!int.TryParse(TxtCurrentDiscount.Text, out int currentDiscount) || currentDiscount < 0 || currentDiscount > 100)
            {
                MessageBox.Show("Действующая скидка должна быть числом от 0 до 100%!", "Ошибка валидации");
                return;
            }

            if (currentDiscount > maxDiscount)
            {
                MessageBox.Show("Действующая скидка не может быть больше максимальной!", "Ошибка валидации");
                return;
            }

            string targetImageFileName = oldImageFileName;

            if (!string.IsNullOrEmpty(selectedImagePath))
            {
                try
                {
                    string directoryPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Tovari_import");
                    if (!System.IO.Directory.Exists(directoryPath)) System.IO.Directory.CreateDirectory(directoryPath);

                    targetImageFileName = Guid.NewGuid().ToString().Substring(0, 8) + System.IO.Path.GetExtension(selectedImagePath);
                    string targetFilePath = System.IO.Path.Combine(directoryPath, targetImageFileName);

                    System.IO.File.Copy(selectedImagePath, targetFilePath, true);

                    if (!string.IsNullOrEmpty(oldImageFileName))
                    {
                        string oldFilePath = System.IO.Path.Combine(directoryPath, oldImageFileName);
                        ImgProduct.Source = null;
                        GC.Collect();
                        GC.WaitForPendingFinalizers();

                        if (System.IO.File.Exists(oldFilePath)) System.IO.File.Delete(oldFilePath);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обработке файла изображения: {ex.Message}");
                }
            }

            string sku = isEditMode ? TxtSku.Text.Trim() : GenerateNewSku();
            string category = (ComboCategory.SelectedItem as ComboBoxItem).Content.ToString();

            using (var connection = DatabaseContext.GetConnection())
            {
                try
                {
                    connection.Open();

                    // ЖЕСТКИЕ SQL-ЗАПРОСЫ ПОД ТАБЛИЦУ КОЛЛЕДЖА (с колонкой stock_quantity)
                    string query = isEditMode ?
                        @"UPDATE products 
                          SET product_name = @name, unit = @unit, price = @price, max_discount = @maxDisc, 
                              manufacturer = @manufacturer, supplier = @supplier, product_type = @type, 
                              current_discount = @currDisc, stock_quantity = @stock, description = @desc, image_file = @img 
                          WHERE sku = @sku" :
                        @"INSERT INTO products (sku, product_name, unit, price, max_discount, manufacturer, supplier, product_type, current_discount, stock_quantity, description, image_file) 
                          VALUES (@sku, @name, @unit, @price, @maxDisc, @manufacturer, @supplier, @type, @currDisc, @stock, @desc, @img)";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@sku", sku);
                        command.Parameters.AddWithValue("@name", TxtName.Text.Trim());
                        command.Parameters.AddWithValue("@unit", TxtUnit.Text.Trim());
                        command.Parameters.AddWithValue("@price", price);
                        command.Parameters.AddWithValue("@maxDisc", maxDiscount);
                        command.Parameters.AddWithValue("@currDisc", currentDiscount);
                        command.Parameters.AddWithValue("@manufacturer", TxtManufacturer.Text.Trim());
                        command.Parameters.AddWithValue("@supplier", TxtSupplier.Text.Trim());
                        command.Parameters.AddWithValue("@type", category);
                        command.Parameters.AddWithValue("@stock", stock); // Привязка к правильному параметру @stock
                        command.Parameters.AddWithValue("@desc", TxtDescription.Text.Trim());
                        command.Parameters.AddWithValue("@img", targetImageFileName ?? "");

                        command.ExecuteNonQuery();
                    }

                    MessageBox.Show(isEditMode ? "Товар успешно обновлен!" : $"Товар успешно добавлен с артикулом {sku}!");
                    NavigationService.GoBack();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка сохранения в БД: {ex.Message}");
                }
            }
        }
        //скобка закрывает метод BtnSave_Click

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack) NavigationService.GoBack();
        }
    } 
} 

