﻿using System;
using MySql.Data.MySqlClient;

namespace Lokteva.Iliasova
{
    public static class DatabaseContext
    {
        private static string connectionString = "server=192.168.227.14;port=3306;database=lokteva_Iliasova_Is41;user=user04;password=User04!Pass;charset=utf8;";

        public static MySqlConnection GetConnection()
        {
            return new MySqlConnection(connectionString);
        }
    }
}
