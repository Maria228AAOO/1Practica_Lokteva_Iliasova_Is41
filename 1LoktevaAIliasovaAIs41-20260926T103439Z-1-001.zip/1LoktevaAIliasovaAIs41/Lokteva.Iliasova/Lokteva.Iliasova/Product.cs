﻿using System;
using System.IO;

namespace Lokteva.Iliasova
{
    public class Product
    {
        public string Sku { get; set; }
        public string ProductName { get; set; }
        public string Unit { get; set; }
        public decimal Price { get; set; }
        public int MaxDiscount { get; set; }
        public string Manufacturer { get; set; }
        public string Supplier { get; set; }
        public string ProductType { get; set; }
        public int CurrentDiscount { get; set; }
        public int Stock { get; set; }
        public string Description { get; set; }
        public string ImageFile { get; set; }

        public string FullImagePath
        {
            get
            {
                // Находим, где реально лежит папка Tovari_import
                string folderPath = "";
                string currentDir = AppDomain.CurrentDomain.BaseDirectory;

                // Метод ищет папку Tovari_import, поднимаясь вверх по каталогам, если мы в bin/Debug
                for (int i = 0; i < 5; i++)
                {
                    string testPath = Path.Combine(currentDir, "Tovari_import");
                    if (Directory.Exists(testPath))
                    {
                        folderPath = testPath;
                        break;
                    }
                    var parent = Directory.GetParent(currentDir);
                    if (parent == null) break;
                    currentDir = parent.FullName;
                }

                // Если папку вообще не нашли на компьютере, возвращаем null
                if (string.IsNullOrEmpty(folderPath)) return null;

                // Настраиваем путь к заглушке
                string stubPath = Path.Combine(folderPath, "picture.png");
                if (!File.Exists(stubPath)) stubPath = Path.Combine(folderPath, "picture");

                // 1. Если имя файла в БД пустое — отдаем заглушку
                if (string.IsNullOrWhiteSpace(ImageFile))
                {
                    return File.Exists(stubPath) ? stubPath : null;
                }

                string rawName = ImageFile.Trim();
                string nameWithoutExt = Path.GetFileNameWithoutExtension(rawName);

                // 2. Проверяем все варианты расширений на диске
                string pathAsIs = Path.Combine(folderPath, rawName);
                string pathJpg = Path.Combine(folderPath, nameWithoutExt + ".jpg");
                string pathNoExt = Path.Combine(folderPath, nameWithoutExt);

                if (File.Exists(pathAsIs)) return pathAsIs;
                if (File.Exists(pathJpg)) return pathJpg;
                if (File.Exists(pathNoExt)) return pathNoExt;

                // 3. Если конкретный файл не найден — возвращаем заглушку
                return File.Exists(stubPath) ? stubPath : null;
            }
        }
    }
}
