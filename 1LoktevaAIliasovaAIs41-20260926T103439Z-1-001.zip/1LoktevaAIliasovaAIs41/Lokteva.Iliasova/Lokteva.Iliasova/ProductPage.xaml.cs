﻿using Lokteva.Iliasova;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;  
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lokteva.Iliasova
{
    public partial class ProductPage : Page
    {
        private List<Product> allProducts = new List<Product>();
        public Visibility AdminControlsVisibility { get; set; } = Visibility.Collapsed;

        public ProductPage()
        {
            InitializeComponent();
            DataContext = this;

            Loaded += (s, e) => {
                var win = Window.GetWindow(this);
                if (win != null)
                {
                    win.Title = AuthService.CurrentRole == "Администратор" ? "Ювелир. Окно администратора" : "Ювелир. Просмотр товаров";
                }

                LoadProductsFromDatabase();
                FillManufacturerComboBox(); // Динамически наполняем выпадающий список брендов
            };

            TxtUserDisplay.Text = AuthService.CurrentUserFullName;

            if (AuthService.CurrentRole == "Администратор")
            {
                BtnAddProduct.Visibility = Visibility.Visible;
                AdminControlsVisibility = Visibility.Visible;
            }
        }

        private void LoadProductsFromDatabase()
        {
            allProducts.Clear();
            using (var connection = DatabaseContext.GetConnection())
            {
                try
                {
                    connection.Open();
                    string query = "SELECT * FROM products";
                    using (var command = new MySqlCommand(query, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                allProducts.Add(new Product
                                {
                                    Sku = reader["sku"].ToString(),
                                    ProductName = reader["product_name"].ToString(),
                                    Unit = reader["unit"].ToString(),
                                    Price = Convert.ToDecimal(reader["price"]),
                                    MaxDiscount = Convert.ToInt32(reader["max_discount"]),
                                    Manufacturer = reader["manufacturer"].ToString(),
                                    Supplier = reader["supplier"].ToString(),
                                    ProductType = reader["product_type"].ToString(),
                                    CurrentDiscount = Convert.ToInt32(reader["current_discount"]),
                                    Stock = Convert.ToInt32(reader["stock_quantity"]),
                                    Description = reader["description"].ToString(),
                                    ImageFile = reader["image_file"].ToString()
                                });
                            }
                        }
                    }
                    UpdateCatalogDisplay();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки товаров из БД: {ex.Message}");
                }
            }
        }

        // Динамическое заполнение списка производителей на основе данных из БД
        private void FillManufacturerComboBox()
        {
            if (ComboManufacturer == null) return;

            // Чтобы не сбрасывать выбор при обновлении, запомним, что было выбрано
            string currentSelected = ComboManufacturer.SelectedItem?.ToString();

            ComboManufacturer.Items.Clear();
            ComboManufacturer.Items.Add("Все производители"); // Пункт 2 ТЗ

            // Берем только уникальные непустые имена производителей из нашего списка
            var manufacturers = allProducts.Select(p => p.Manufacturer).Where(m => !string.IsNullOrEmpty(m)).Distinct().OrderBy(m => m);

            foreach (var m in manufacturers)
            {
                ComboManufacturer.Items.Add(m);
            }

            // Возвращаем старый выбор или ставим первый пункт по умолчанию
            if (currentSelected != null && ComboManufacturer.Items.Contains(currentSelected))
                ComboManufacturer.SelectedItem = currentSelected;
            else
                ComboManufacturer.SelectedIndex = 0;
        }

        // ЦЕНТРАЛЬНЫЙ МЕТОД: Поиск, фильтрация и сортировка работают СОВМЕСТНО и в реальном времени
        private void UpdateCatalogDisplay()
        {
            if (TxtSearch == null || ComboSort == null || ComboManufacturer == null) return;

            List<Product> filtered = new List<Product>(allProducts);

            // 1. ПРИМЕНЯЕМ УМНЫЙ ПОИСК (по нескольким атрибутам одновременно: название, описание, производитель, SKU)
            string searchWord = TxtSearch.Text.ToLower().Trim();
            if (!string.IsNullOrEmpty(searchWord))
            {
                filtered = filtered.Where(p =>
                    p.ProductName.ToLower().Contains(searchWord) ||
                    p.Description.ToLower().Contains(searchWord) ||
                    p.Manufacturer.ToLower().Contains(searchWord) ||
                    p.Sku.ToLower().Contains(searchWord)
                ).ToList();
            }

            // 2. ПРИМЕНЯЕМ ФИЛЬТРАЦИЮ ПО ПРОИЗВОДИТЕЛЮ
            if (ComboManufacturer.SelectedIndex > 0) // Если выбран конкретный производитель, а не "Все производители"
            {
                string selectedManufacturer = ComboManufacturer.SelectedItem.ToString();
                filtered = filtered.Where(p => p.Manufacturer == selectedManufacturer).ToList();
            }

            // 3. ПРИМЕНЯЕМ СОРТИРОВКУ ПО СТОИМОСТИ (с сохранением параметров фильтрации)
            if (ComboSort.SelectedIndex == 1) // По возрастанию
            {
                filtered = filtered.OrderBy(p => p.Price).ToList();
            }
            else if (ComboSort.SelectedIndex == 2) // По убыванию
            {
                filtered = filtered.OrderByDescending(p => p.Price).ToList();
            }

            // Выводим результат в ListBox
            ProductsListBox.ItemsSource = null;
            ProductsListBox.ItemsSource = filtered;

            // Обновляем счетчик количества товаров
            TxtCounter.Text = $"{filtered.Count} из {allProducts.Count}";
        }

        // Триггеры изменения состояния — сразу вызывают общий метод обновления экрана
        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateCatalogDisplay();
        }

        private void ComboSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateCatalogDisplay();
        }

        private void ComboManufacturer_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateCatalogDisplay();
        }

        // Обновленная кнопка Удалить с проверкой по ТЗ (Товары в заказах)
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var product = button?.Tag as Product;

            if (product == null) return;

            // 1. Сначала спрашиваем подтверждение у пользователя (требование из прошлых пунктов)
            MessageBoxResult confirmResult = MessageBox.Show(
                $"Вы действительно хотите удалить товар {product.ProductName}?",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (confirmResult != MessageBoxResult.Yes) return;

            using (var connection = DatabaseContext.GetConnection())
            {
                try
                {
                    connection.Open();

                    // ШАГ 1: Проверяем, присутствует ли этот товар в заказах (таблица order_items)
                    string checkOrderQuery = "SELECT COUNT(*) FROM order_items WHERE product_sku = @sku";
                    using (var checkCmd = new MySqlCommand(checkOrderQuery, connection))
                    {
                        checkCmd.Parameters.AddWithValue("@sku", product.Sku);
                        long ordersCount = Convert.ToInt64(checkCmd.ExecuteScalar());

                        if (ordersCount > 0)
                        {
                            // ПУНКТ 1 ТЗ: Если товар есть в заказе — выводим ошибку и запрещаем удаление!
                            MessageBox.Show(
                                "Этот товар присутствует в оформленных заказах! Удаление невозможно.",
                                "Ошибка удаления",
                                MessageBoxButton.OK,
                                MessageBoxImage.Warning);
                            return; // Выходим из метода, ничего не удаляя
                        }
                    }

                    // ШАГ 2: Если товар НЕ заказан, проверяем и удаляем связанные/дополнительные данные.
                    // Сначала мы должны очистить информацию о дополнительных товарах в order_items (если они там были привязаны),
                    // чтобы MySQL не ругался на Foreign Key (внешние ключи).
                    string deleteOrderItemsQuery = "DELETE FROM order_items WHERE product_sku = @sku";
                    using (var deleteItemsCmd = new MySqlCommand(deleteOrderItemsQuery, connection))
                    {
                        deleteItemsCmd.Parameters.AddWithValue("@sku", product.Sku);
                        deleteItemsCmd.ExecuteNonQuery();
                    }

                    // ШАГ 3: Теперь со спокойной совестью удаляем сам основной товар из таблицы products
                    string deleteProductQuery = "DELETE FROM products WHERE sku = @sku";
                    using (var deleteProdCmd = new MySqlCommand(deleteProductQuery, connection))
                    {
                        deleteProdCmd.Parameters.AddWithValue("@sku", product.Sku);
                        deleteProdCmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Товар и вся связанная информация успешно удалены из базы данных.", "Успех");

                    // Перезагружаем список товаров на экране, чтобы удаленный товар сразу исчез
                    LoadProductsFromDatabase();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при выполнении операции удаления: {ex.Message}", "Ошибка БД");
                }
            }
        }


        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var product = button?.Tag as Product;
            if (product != null) NavigationService.Navigate(new ProductEditPage(product));
        }

        private void BtnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductEditPage(null));
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack) NavigationService.GoBack();
        }
    }
}
