﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lokteva.Iliasova
{
    public static class AuthService
    {
        public static string CurrentRole { get; set; } = "Гость";
        public static string CurrentUserFullName { get; set; } = "Гость";
    }
}

