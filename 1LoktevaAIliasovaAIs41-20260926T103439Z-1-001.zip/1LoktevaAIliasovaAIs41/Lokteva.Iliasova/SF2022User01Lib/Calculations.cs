﻿using System;
using System.Collections.Generic;

namespace SF2022User01Lib
{
    public class Calculations
    {
        public static string[] AvailablePeriods(
            TimeSpan[] startTimes,
            int[] durations,
            TimeSpan beginWorkingTime,
            TimeSpan endWorkingTime,
            int consultationTime)
        {
            List<string> result = new List<string>();

            // 1. Создаем список всех занятых интервалов (начало и конец)
            List<KeyValuePair<TimeSpan, TimeSpan>> busyIntervals = new List<KeyValuePair<TimeSpan, TimeSpan>>();
            for (int i = 0; i < startTimes.Length; i++)
            {
                TimeSpan start = startTimes[i];
                TimeSpan end = start.Add(TimeSpan.FromMinutes(durations[i]));
                busyIntervals.Add(new KeyValuePair<TimeSpan, TimeSpan>(start, end));
            }

            // Длина консультации в TimeSpan
            TimeSpan consultSpan = TimeSpan.FromMinutes(consultationTime);

            // 2. Идем по рабочему дню с шагом в 1 минуту (или сразу шагать по консультации)
            TimeSpan currentTime = beginWorkingTime;

            while (currentTime + consultSpan <= endWorkingTime)
            {
                TimeSpan targetEnd = currentTime + consultSpan;
                bool isBusy = false;

                // Проверяем, пересекается ли текущий потенциальный слот с любым занятым временем
                foreach (var busy in busyIntervals)
                {
                    // Слот занят, если он начинается до окончания занятого периода И заканчивается после начала занятого периода
                    if (currentTime < busy.Value && targetEnd > busy.Key)
                    {
                        isBusy = true;
                        // Сдвигаем текущее время на конец этого занятого периода, чтобы не тратить циклы
                        currentTime = busy.Value;
                        break;
                    }
                }

                // Если время свободно — записываем слот в результат
                if (!isBusy)
                {
                    string slotStr = $"{currentTime:hh\\:mm}-{targetEnd:hh\\:mm}";
                    result.Add(slotStr);

                    // Переходим к началу следующего потенциального слота
                    currentTime = targetEnd;
                }
            }

            return result.ToArray();
        }
    }
}
